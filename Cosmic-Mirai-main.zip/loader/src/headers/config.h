#pragma once

#define HTTP_SERVER "103.127.30.87"
#define HTTP_PORT 80

#define TFTP_SERVER "103.127.30.87"
